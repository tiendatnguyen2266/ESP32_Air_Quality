Install Adafruit SSD1306, Adafruit GFX Library & Adafruit BusIO from the Arduino Library Manager

Versions used for testing
Adafruit SSD1306 version 2.3.1
Adafruit GFX Library version 1.9.0
Adafruit BusIO version 1.3.3